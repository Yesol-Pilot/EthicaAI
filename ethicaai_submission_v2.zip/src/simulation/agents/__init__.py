"""
에이전트 패키지 초기화
"""
from typing import Dict, Any, List

# 추후 구현될 에이전트 클래스들 (BaseAgent, SelfishAgent, OptimalAgent, BoundedAgent)
# from simulation.agents.base_agent import BaseAgent
# ...

__all__: List[str] = []

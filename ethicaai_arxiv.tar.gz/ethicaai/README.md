# EthicaAI — arXiv Submission Package

- Primary: cs.AI
- Cross-list: cs.MA, cs.GT
- License: CC BY 4.0
- Figures: 20

## Build
```
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```
